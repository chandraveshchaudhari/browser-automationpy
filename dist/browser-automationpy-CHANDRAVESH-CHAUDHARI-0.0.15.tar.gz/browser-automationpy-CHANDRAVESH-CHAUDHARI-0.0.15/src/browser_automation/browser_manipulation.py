from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from browser_automation import browser_setup
from browser_automation import os_json_utils
from browser_automation import locate_elements


class Interactions(browser_setup.Setup):
    """
    This is class for doing manipulations with web elements using selenium drivers.
    """
    def __init__(self):
        super().__init__()

    def driver_wait(self, time_duration):
        # Setup wait for later
        return WebDriverWait(self.driver, time_duration)

    def change_window(self):
        """
        It changes the current window to last window in browser

        Returns
        -------

        """
        # Store the ID of the original window
        original_window = self.driver.current_window_handle
        # ID of all windows
        all_windows = self.driver.window_handles
        needed_window = all_windows[-1]
        # move to the last window
        if needed_window != original_window:
            self.driver.switch_to.window(needed_window)

    def scroll_page(self, scroll_until: int = 4000, scroll_height: int = 200):
        """
        this scroll the page to load all of details

        Parameters
        ----------
        scroll_until
        scroll_height

        Returns
        -------

        """
        scroll = 0
        while scroll < scroll_until:
            self.driver.execute_script("window.scrollTo(0," + str(scroll) + " );")
            scroll += scroll_height

    def get_current_webpage(self):
        """
        html_source_code: complete html of page

        Returns
        -------

        """
        html_source_code = self.driver.page_source
        return html_source_code

    def fill_input_on_webpage(self, word_seen_in_website: str, html_text: str, element_name: str, input_answer: str):
        """
        this function fill the input box on webpage with the help of wordSeenInWebsite, with the inputAnswer.

        Parameters
        ----------
        word_seen_in_website : str
            word that you see in input box on website
        html_text : str
            word that you see in input box on website
        element_name : str
            ID, Name, Class etc. of html element
        input_answer : str
            answer that you want to put in the input box of webpage

        Returns
        -------
        None

        """
        element_value = locate_elements.LocateElements(self.get_current_webpage()).get_element_value_from_html(word_seen_in_website,
                                                                                               element_name)
        for value in element_value:
            try:
                print(value)
                print(type(value))
                input_box = self.driver.find_element(By.ID, str(value))
                input_box.clear()
                input_box.send_keys(input_answer)
                print("executed")
            except Exception:
                print('passing')
                pass

    def input_box_by_name(self, name: str, answer: str):
        """
        Input answer in input box by searching element Name

        Parameters
        ----------
        name
        answer

        Returns
        -------

        """
        try:
            user_field = self.driver.find_element(By.NAME, name)
            user_field.clear()
            user_field.send_keys(answer)
        except Exception:
            print(Exception)

    def input_box_by_xpath(self, xpath_element: str, answer: str):
        """
        Input answer in input box by searching element Name

        Parameters
        ----------
        xpath_element
        answer

        Returns
        -------

        """
        try:
            input_box = self.driver.find_element(By.XPATH, xpath_element)
            input_box.clear()
            input_box.send_keys(answer)
        except Exception:
            print(Exception)

    def write_in_input_box(self, element_locator_type: str, element_locator_path: str, input_answer: str):
        """
        Input answer in input box by searching element_locator_path

        Parameters
        ----------
        element_locator_type : str
            these by selenium methods to locate web element. This function contains
            CLASS_NAME, CSS_SELECTOR, ID, LINK_TEXT, NAME, PARTIAL_LINK_TEXT, TAG_NAME, XPATH.
        element_locator_path : str
            path of above given element_locator_type
        input_answer

        Returns
        -------
        None

        """
        try:
            if element_locator_type.upper() == "CLASS_NAME":
                input_box = self.driver.find_element(By.CLASS_NAME, element_locator_path)
            elif element_locator_type.upper() == "CSS_SELECTOR":
                input_box = self.driver.find_element(By.CSS_SELECTOR, element_locator_path)
            elif element_locator_type.upper() == "ID":
                input_box = self.driver.find_element(By.ID, element_locator_path)
            elif element_locator_type.upper() == "LINK_TEXT":
                input_box = self.driver.find_element(By.LINK_TEXT, element_locator_path)
            elif element_locator_type.upper() == "NAME":
                input_box = self.driver.find_element(By.NAME, element_locator_path)
            elif element_locator_type.upper() == "PARTIAL_LINK_TEXT":
                input_box = self.driver.find_element(By.PARTIAL_LINK_TEXT, element_locator_path)
            elif element_locator_type.upper() == "TAG_NAME":
                input_box = self.driver.find_element(By.TAG_NAME, element_locator_path)
            elif element_locator_type.upper() == "XPATH":
                input_box = self.driver.find_element(By.XPATH, element_locator_path)
            else:
                print(
                    "This function doesn't implement your element_locator_type, please try modifying this function or "
                    "write separately!")
                return
            input_box.clear()
            input_box.send_keys(input_answer)
        except Exception:
            print("element locator path can not be found")

    def click_on_button(self, element_locator_type: str, element_locator_path: str):
        """
        click on button on web by searching element_locator_path. exceptions silenced

        Parameters
        ----------
        element_locator_type : str
            these by selenium methods to locate web element. This function contains CLASS_NAME, CSS_SELECTOR, ID,
            LINK_TEXT, NAME, PARTIAL_LINK_TEXT, TAG_NAME, XPATH.
        element_locator_path : str
            path of above given element_locator_type

        Returns
        -------

        """
        try:
            if element_locator_type.upper() == "CLASS_NAME":
                button = self.driver.find_element(By.CLASS_NAME, element_locator_path)
            elif element_locator_type.upper() == "CSS_SELECTOR":
                button = self.driver.find_element(By.CSS_SELECTOR, element_locator_path)
            elif element_locator_type.upper() == "ID":
                button = self.driver.find_element(By.ID, element_locator_path)
            elif element_locator_type.upper() == "LINK_TEXT":
                button = self.driver.find_element(By.LINK_TEXT, element_locator_path)
            elif element_locator_type.upper() == "NAME":
                button = self.driver.find_element(By.NAME, element_locator_path)
            elif element_locator_type.upper() == "PARTIAL_LINK_TEXT":
                button = self.driver.find_element(By.PARTIAL_LINK_TEXT, element_locator_path)
            elif element_locator_type.upper() == "TAG_NAME":
                button = self.driver.find_element(By.TAG_NAME, element_locator_path)
            elif element_locator_type.upper() == "XPATH":
                button = self.driver.find_element(By.XPATH, element_locator_path)
            else:
                print(
                    "This function doesn't implement your element_locator_type, please try modifying this function or "
                    "write separately!")
                return
            button.click()
        except Exception:
            print("element locator path can not be found")

    def website_login(self, url: str,
                      username_element_locator_type: str, username_element_locator_path: str, username: str,
                      password_element_locator_type: str, password_element_locator_path: str, password: str,
                      login_button_element_locator_type: str, login_button_element_locator_path: str,
                      login_option_element_locator_type=None, login_option_element_locator_path: str = None):
        """
        login into website using these arguments Args: driver: url: username_element_name: username: this
        is the username of person already sign up on website password: password for above username of account

        Parameters
        ----------
        url
        username_element_locator_type
        username_element_locator_path
        username
        password_element_locator_type : str
            this is the password element name in website
        password_element_locator_path : str

        password
        login_button_element_locator_type
        login_button_element_locator_path
        login_option_element_locator_type
        login_option_element_locator_path

        Returns
        -------

        """
        print(f"Going to website: {url}")
        self.driver.get(url)
        os_json_utils.RandomSleep().sleep_for_random_time()
        if login_option_element_locator_path is not None:
            self.click_on_button(login_option_element_locator_type, login_option_element_locator_path)
        self.write_in_input_box(username_element_locator_type, username_element_locator_path, username)
        os_json_utils.RandomSleep().sleep_for_random_time()
        self.write_in_input_box(password_element_locator_type, password_element_locator_path, password)
        self.click_on_button(login_button_element_locator_type, login_button_element_locator_path)
        os_json_utils.RandomSleep().sleep_for_random_time()

    def button_click_by_xpath(self, button_element_xpath):
        """
        ButtonElementXpath used to find and click on the button

        Parameters
        ----------
        button_element_xpath

        Returns
        -------

        """
        try:
            button = self.driver.find_element(By.XPATH, button_element_xpath)
            button.click()
        except Exception:
            print(Exception)

    def articles_gathering_loop(self, articles_name_list, initial_search_link, pdf_button_locator_element_xpath,
                                destination_folder_path, scroll=False, open_button=False):
        for article_name in articles_name_list:
            self.create_article_weblink_and_browse(initial_search_link, article_name)
            os_json_utils.RandomSleep().sleep_for_random_time()
            if scroll:
                self.scroll_page(400, 300)
            self.click_on_button("xpath", pdf_button_locator_element_xpath)
            os_json_utils.RandomSleep().sleep_for_random_time()
            if open_button:
                open_pdf_button_link = locate_elements.LocateElements(self.get_current_webpage()).get_link_via_regex()
                self.driver.get(open_pdf_button_link)
            print("file downloaded")
            os_json_utils.DownloadUtil(self.download_dir).file_rename_and_moving(destination_folder_path, article_name)

    def create_article_weblink_and_browse(self, initial_search_link, article_name):
        full_search_site_link = initial_search_link + article_name
        print(f"trying to download article: {article_name}")
        self.driver.get(full_search_site_link)

    # This is worst case of finding different addresses for same web element on website
    def web_element_multiple_try_to_click_or_write(self, list_of_element_locator_types_with_addresses,
                                                   write_something=None):
        """
        This function takes list of element_locator types with addresses to click or write in input_box.

        Parameters
        ----------
        list_of_element_locator_types_with_addresses : str
            This is the list with element_locator_types such as CLASS_NAME,CSS_SELECTOR, ID, LINK_TEXT, NAME,
            PARTIAL_LINK_TEXT, TAG_NAME, XPATH with respective addresses. example- ["id", "result-header-1", "xpath",
            "//h3[@id='result-header-1']"]
        write_something : str
            default is None which signify that click() function will be executed. if you want to write something in
            found web element, please replace None to your input string.

        Returns
        -------

        """
        assert (type(write_something) == str)
        web_element = self.multiple_try_to_find_web_element(list_of_element_locator_types_with_addresses)
        if web_element is None:
            print("web_element is not found: please revisit your strategy or create a new function")
            return
        if write_something is None:
            web_element.click()
        else:
            web_element.clear()
            web_element.send_keys(write_something)

    def multiple_try_to_find_web_element(self, list_of_element_locator_types_with_addresses):
        """
        This functions uses multiple try statements to find_web_element

        Parameters
        ----------
        list_of_element_locator_types_with_addresses : str
            This is the list with element_locator_types such as CLASS_NAME,CSS_SELECTOR, ID, LINK_TEXT, NAME,
            PARTIAL_LINK_TEXT, TAG_NAME, XPATH with respective addresses. example- ["id", "result-header-1", "xpath",
            "//h3[@id='result-header-1']"]

        Returns
        -------

        """
        length_of_list_of_element_locator_types_with_addresses = len(list_of_element_locator_types_with_addresses)
        assert (length_of_list_of_element_locator_types_with_addresses >= 2) and (
                length_of_list_of_element_locator_types_with_addresses % 2 == 0)
        web_element_found = False
        element_locator_types_index = 0
        while not web_element_found:
            element_locator_path_index = element_locator_types_index + 1
            print(element_locator_types_index, element_locator_path_index)
            result = self.try_element_address(list_of_element_locator_types_with_addresses[element_locator_types_index],
                                              list_of_element_locator_types_with_addresses[element_locator_path_index])
            web_element_found, web_element = result[0], result[1]
            element_locator_types_index += 2
            if element_locator_types_index > length_of_list_of_element_locator_types_with_addresses - 1:
                print("this stops")
                return web_element

    def try_element_address(self, element_locator_type, element_locator_path):
        """
        this is try except block for searching element via element_locator_type, element_locator_path

        Parameters
        ----------
        element_locator_type : str
            these by selenium methods to locate web element. This function contains
                CLASS_NAME, CSS_SELECTOR, ID, LINK_TEXT, NAME, PARTIAL_LINK_TEXT, TAG_NAME, XPATH.
        element_locator_path

        Returns
        -------

        """
        try:
            print("trying")
            web_element = self.find_web_element(element_locator_type, element_locator_path)
            web_element_found = True
        except Exception:
            web_element_found = False
            web_element = None
        return web_element_found, web_element

    def find_web_element(self, element_locator_type: str, element_locator_path: str):
        """
        click on button on web by searching element_locator_path

        Parameters
        ----------
        element_locator_type : str
            these by selenium methods to locate web element. This function contains
                CLASS_NAME, CSS_SELECTOR, ID, LINK_TEXT, NAME, PARTIAL_LINK_TEXT, TAG_NAME, XPATH.
        element_locator_path

        Returns
        -------
        object
            selenium.webdriver.remote.webelement.WebElement, It could be input_box or button etc.

        """
        if element_locator_type.upper() == "CLASS_NAME":
            web_element = self.driver.find_element(By.CLASS_NAME, element_locator_path)
        elif element_locator_type.upper() == "CSS_SELECTOR":
            web_element = self.driver.find_element(By.CSS_SELECTOR, element_locator_path)
        elif element_locator_type.upper() == "ID":
            web_element = self.driver.find_element(By.ID, element_locator_path)
        elif element_locator_type.upper() == "LINK_TEXT":
            web_element = self.driver.find_element(By.LINK_TEXT, element_locator_path)
        elif element_locator_type.upper() == "NAME":
            web_element = self.driver.find_element(By.NAME, element_locator_path)
        elif element_locator_type.upper() == "PARTIAL_LINK_TEXT":
            web_element = self.driver.find_element(By.PARTIAL_LINK_TEXT, element_locator_path)
        elif element_locator_type.upper() == "TAG_NAME":
            web_element = self.driver.find_element(By.TAG_NAME, element_locator_path)
        elif element_locator_type.upper() == "XPATH":
            web_element = self.driver.find_element(By.XPATH, element_locator_path)
        else:
            raise ValueError("This function doesn't implement your element_locator_type, please try modifying this "
                             "function or write separately!")
        return web_element


if __name__ == "main":
    pass
