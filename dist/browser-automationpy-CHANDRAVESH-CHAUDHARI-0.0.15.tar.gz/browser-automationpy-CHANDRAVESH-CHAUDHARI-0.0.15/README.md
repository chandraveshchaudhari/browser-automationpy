# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

![Python Logo](./data/markus-spiske-Skf7HxARcoc-unsplash.jpg "Sample inline image")

refererence
https://choosealicense.com/

https://packaging.python.org/tutorials/packaging-projects/
https://github.com/pypa/sampleproject
https://www.python.org/dev/peps/pep-0008/#package-and-module-names
https://realpython.com/pypi-publish-python-package/


https://pypi.org/project/webdriver-manager/



