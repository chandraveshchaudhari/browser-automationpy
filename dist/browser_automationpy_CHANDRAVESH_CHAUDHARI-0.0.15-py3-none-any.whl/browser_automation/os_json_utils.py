import json
import os
import platform
import shutil
import time
import pyautogui
import random


def finding_grandparent_dir_from_cwd():
    present_dir = os.getcwd()
    parent_dir = os.path.dirname(present_dir)
    grandparent_dir = os.path.dirname(parent_dir)
    return grandparent_dir


def config_file_path(config_name="config.json"):
    grandparent_dir = finding_grandparent_dir_from_cwd()
    config_path = os.path.join(grandparent_dir, config_name)
    return config_path


def read_json_file_from_path(json_file_path):
    with open(json_file_path, 'r') as openfile:
        # Reading from json file
        json_object = json.load(openfile)
        return json_object


def write_json_file_with_dict(output_file_path, input_dict):
    with open(output_file_path, "w") as outfile:
        json.dump(input_dict, outfile)


def avoid_lock():
    """
    this uses mouse and keyboard to act human is using the computer

    Returns
    -------

    """
    x, _ = pyautogui.position()
    pyautogui.moveTo(x + 200, pyautogui.position().y, duration=1.0)
    pyautogui.moveTo(x, pyautogui.position().y, duration=0.5)
    pyautogui.keyDown('ctrl')
    pyautogui.press('esc')
    pyautogui.keyUp('ctrl')
    pyautogui.press('esc')


def sleep(time_duration):
    """
    this function sleep for given Time

    Parameters
    ----------
    time_duration

    Returns
    -------

    """
    print(f"Sleeping for {round(time_duration, 1)}")
    time.sleep(time_duration)


def get_download_location_path():
    current_os = platform.system()
    username = os.getlogin()
    if current_os == "Linux":
        default_download_path = f"/home/{username}/Downloads"
    elif current_os == "Darwin":
        default_download_path = f"/Users/{username}/Downloads"
    elif current_os == "Windows":
        default_download_path = f"\\Users\\{username}\\Downloads"
    else:
        default_download_path = input("please provide the default download location of your browser")
    return default_download_path


class RandomSleep:
    def __init__(self, lower_time_limit=5, upper_time_limit=15.3):
        self.lower_time_limit = lower_time_limit
        self.upper_time_limit = upper_time_limit

    def random_time(self):
        """
        this gives random_time between lower_time_limit and upper_time_limit

        Returns
        -------

        """
        random_out_time = random.uniform(self.lower_time_limit, self.upper_time_limit)
        return random_out_time

    def sleep_for_random_time(self):
        """
        this sleep for some time

        Returns
        -------

        """
        random_time_duration = self.random_time()
        print(f"Sleeping for {round(random_time_duration, 1)}")
        time.sleep(random_time_duration)

    def sleep_after_n_monotonous_work(self, n: int, monotonous_work, random_sleep_multiple=15):
        """
        sleep every n applications

        Parameters
        ----------
        n
        monotonous_work
        random_sleep_multiple

        Returns
        -------

        """
        if monotonous_work != 0 and monotonous_work % n == 0:
            time.sleep(random_sleep_multiple * self.random_time())


class DownloadUtil:
    def __init__(self, download_dir):
        self.download_dir = download_dir

    def download_completion_wait(self, timeout=300, files_counts=None):
        """
        Wait for downloads to finish with a specified timeout.
        author: https://stackoverflow.com/questions/34338897/python-selenium-find-out-when-a-download-has-completed

        Parameters
        ----------
        timeout : int
            How many seconds to wait until timing out.
        files_counts : str
            If provided, also wait for the expected number of files.

        Returns
        -------

        """
        seconds = 0
        waiting = True
        while waiting and seconds < timeout:
            time.sleep(1)
            waiting = False
            files = os.listdir(self.download_dir)
            if files_counts and len(files) != files_counts:
                waiting = True

            for filename in files:
                if filename.endswith('.crdownload'):
                    waiting = True

            seconds += 1

    def file_rename_and_moving(self, destination_folder_path, new_name=None):
        """
        This function waits with timeout option until file is downloaded in origin folder. then
        rename and move it to destination folder.

        Parameters
        ----------
        destination_folder_path
        new_name

        Returns
        -------

        """
        self.download_completion_wait()
        filename = max([self.download_dir + "/" + f for f in os.listdir(self.download_dir)], key=os.path.getctime)
        if new_name:
            name_with_extension = replace_symbols_with_space(str(new_name)) + ".pdf"
            shutil.move(filename, os.path.join(destination_folder_path, str(name_with_extension)))
        else:
            shutil.move(filename, os.path.join(destination_folder_path, str(os.path.basename(filename))))
        print("file renamed and moved")


def replace_symbols_with_space(string):
    alpha = ""
    for character in string:
        if character.isalpha():
            alpha += character
        elif character == " ":
            alpha += character
        else:
            alpha += " "
    return alpha


if __name__ == "main":
    pass
